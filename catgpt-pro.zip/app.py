
import streamlit as st
import sqlite3
from difflib import get_close_matches

# Örnek senaryo verileri
scenarios = [
    {"keyword": "tüy dökülmesi", "response": "Kedinizin tüy dökmesi mevsimsel olabilir. Ancak aşırıysa veteriner kontrolü gerekebilir."},
    {"keyword": "ishal", "response": "Kediniz ishal olduysa bol su vermeli ve 12 saat mama vermeyip gözlemlemelisiniz."},
    {"keyword": "miyavlama", "response": "Kediniz çok miyavlıyorsa ilgi, açlık ya da hastalık belirtisi olabilir."},
    {"keyword": "aşı takvimi", "response": "Yavru kediler için temel aşılar 2. aydan itibaren başlar ve veterinerinizle takip edilmelidir."},
    {"keyword": "kısırlaştırma", "response": "Kısırlaştırma için ideal zaman dişilerde 6 ay civarıdır, erkeklerde değişebilir."}
]

def ai_response(question, age, breed, gender):
    base = "CatGPT Uzmanı:"
    details = f" ({age} yaşında, {gender}, {breed})"
    answer = f"{base} Sorunuz değerlendirildi.{details}. Bu durumda profesyonel önerim: Veteriner kontrolü gerekli olabilir, ancak benzer durumlarda genellikle çevresel stres, beslenme değişimi veya cinsiyete bağlı hormonal etkenler öne çıkar."
    return answer

# Veritabanı bağlantısı
conn = sqlite3.connect("catgpt_data.db", check_same_thread=False)
cursor = conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS chat_log (id INTEGER PRIMARY KEY AUTOINCREMENT, cat_name TEXT, question TEXT, response TEXT)")
conn.commit()

# Arayüz
st.set_page_config(page_title="CatGPT", page_icon="🐱", layout="centered")
st.title("🐾 CatGPT - Kedi Danışmanı")

# Kedi adı oturumu
cat_name = st.text_input("Kedinizin Adı", help="Verilerin doğru kaydı için kedinizin adını giriniz.")
if not cat_name:
    st.warning("Devam etmek için lütfen kedinizin adını girin.")
    st.stop()

tab1, tab2, tab3, tab4 = st.tabs(["🐱 Soru-Cevap", "🧬 Irklar", "🛁 Bakım", "📜 Sağlık Geçmişi"])

with tab1:
    st.markdown("Kedinle ilgili sorunu yaz, CatGPT yanıtlasın!")

    col1, col2, col3 = st.columns(3)
    with col1:
        age = st.selectbox("Kedinizin Yaşı", ["Yavru", "1", "2", "3", "4", "5+"])
    with col2:
        breed = st.text_input("Irk (örn. Scottish Fold, Van Kedisi)")
    with col3:
        gender = st.radio("Cinsiyet", ["Dişi", "Erkek"])

    user_input = st.text_input("Sorunuzu yazın:")

    if st.button("Sor"):
        if user_input.strip() == "":
            st.warning("Lütfen bir soru yazın.")
        else:
            prompt = user_input.strip().lower()
            keywords = [item["keyword"] for item in scenarios]
            match = get_close_matches(prompt, keywords, n=1, cutoff=0.3)

            if match:
                for item in scenarios:
                    if item["keyword"] == match[0]:
                        response = item["response"]
                        break
            else:
                response = ai_response(user_input, age, breed or "bilinmeyen", gender)

            st.success(response)
            cursor.execute("INSERT INTO chat_log (cat_name, question, response) VALUES (?, ?, ?)", (cat_name, user_input, response))
            conn.commit()

with tab2:
    st.subheader("Popüler Kedi Irkları")
    st.markdown("""
- **British Shorthair**: Sakin ve uysaldır, apartman yaşamına uygundur.
- **Scottish Fold**: Katlanık kulakları ile meşhurdur.
- **Siyam**: Sosyal, zeki ve konuşkandır.
- **Van Kedisi**: Türkiye kökenli, yüzmeyi sever.
- **Maine Coon**: Dev gibi ama çok sevecen bir ırk.
""")

with tab3:
    st.subheader("Kedi Bakımı Hakkında Bilgiler")
    st.markdown("""
- **Beslenme**: Kaliteli mama tercih edilmeli, suyu taze olmalı.
- **Tuvalet Eğitimi**: Kum kabı temiz tutulmalı.
- **Tırnak Bakımı**: Tırmalama tahtası ile yönlendirme yapılmalı.
- **Aşı Takibi**: Veteriner kontrolünde düzenli aşı yapılmalı.
- **Tüy Bakımı**: Haftalık tarama yapılmalı, tüy yumağı engellenmeli.
""")

with tab4:
    st.subheader(f"{cat_name} için Geçmiş Sorular ve Yanıtlar")
    cursor.execute("SELECT question, response FROM chat_log WHERE cat_name = ? ORDER BY id DESC LIMIT 20", (cat_name,))
    data = cursor.fetchall()
    if data:
        for q, r in data:
            st.markdown(f"**❓ {q}**")
            st.markdown(f"🟢 {r}")
            st.markdown("---")
    else:
        st.info("Bu kedi için henüz hiç soru sorulmadı.")
