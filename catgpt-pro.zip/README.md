# 🐾 CatGPT Pro

CatGPT, kedi sahiplerinin sorularına yapay zekâ destekli yanıtlar veren bir veteriner danışman uygulamasıdır.

## 🚀 Özellikler
- Sekmeli kullanıcı arayüzü (Irklar, Bakım, Geçmiş)
- Sorulara senaryo tabanlı ve AI destekli yanıt
- Kedi adı ile kişiselleştirilmiş geçmiş kayıt sistemi
- SQLite ile veri kaydı
- Streamlit arayüzü

## 🗂️ Dosya Yapısı
```
catgpt-pro/
│
├── app.py                  # Ana uygulama dosyası
├── data/                   # Veritabanı ve senaryo verileri
├── components/             # Gelişmiş modüller (AI, öneri sistemi)
├── assets/                 # Logo ve görseller (opsiyonel)
└── README.md               # Proje tanımı
```

## 🧪 Başlatmak için:
```bash
pip install -r requirements.txt
streamlit run app.py
```
